import { CANONICAL_CATEGORIES, normalizeCategory } from "../_constants/categories";

export type BudgetActualRow = { category: string; budget: number; actual: number };

export function monthRangeFromYyyymm(yyyymm: string) {
  const y = Number(yyyymm.slice(0, 4));
  const m = Number(yyyymm.slice(4));
  const from = `${y}-${String(m).padStart(2, "0")}-01`;
  const nextM = m === 12 ? 1 : m + 1;
  const nextY = m === 12 ? y + 1 : y;
  const to = `${nextY}-${String(nextM).padStart(2, "0")}-01`;
  return { from, to };
}

/**
 * 予算×実績（当月）を取得してマージして返す
 *  - 予算: budgets(yyyymm)
 *  - 実績: logs(date range, is_income=false)
 *  - カテゴリは normalizeCategory で正規化して集計
 */
export async function fetchBudgetVsActual(
  supabase: any,
  profileId: string,
  yyyymm: string
): Promise<BudgetActualRow[]> {
  // 予算
  const { data: budgets, error: be } = await supabase
    .from("budgets")
    .select("category, amount")
    .eq("profile_id", profileId)
    .eq("yyyymm", yyyymm);

  if (be) throw new Error(`budgets: ${be.message}`);

  // 実績（支出のみ）
  const { from, to } = monthRangeFromYyyymm(yyyymm);
  const { data: logs, error: le } = await supabase
    .from("logs")
    .select("category, amount, is_income, date")
    .eq("profile_id", profileId)
    .gte("date", from)
    .lt("date", to);

  if (le) throw new Error(`logs: ${le.message}`);

  const budgetMap = new Map<string, number>();
  (budgets ?? []).forEach((b: any) => {
    const cat = normalizeCategory(b.category);
    budgetMap.set(cat, (budgetMap.get(cat) ?? 0) + Number(b.amount || 0));
  });

  const actualMap = new Map<string, number>();
  (logs ?? []).forEach((r: any) => {
    if (r.is_income) return; // 収入は除外（支出のみカウント）
    const cat = normalizeCategory(r.category);
    actualMap.set(cat, (actualMap.get(cat) ?? 0) + Number(r.amount || 0));
  });

  const keys = new Set<string>([
    ...CANONICAL_CATEGORIES,
    ...budgetMap.keys(),
    ...actualMap.keys(),
  ]);

  const rows: BudgetActualRow[] = Array.from(keys).map((k) => ({
    category: k,
    budget: budgetMap.get(k) ?? 0,
    actual: actualMap.get(k) ?? 0,
  }));

  // 表示順：正規カテゴリ優先 → その他は五十音
  rows.sort((a, b) => {
    const ai = CANONICAL_CATEGORIES.indexOf(a.category as any);
    const bi = CANONICAL_CATEGORIES.indexOf(b.category as any);
    const ra = ai === -1 ? 999 : ai;
    const rb = bi === -1 ? 999 : bi;
    if (ra !== rb) return ra - rb;
    return a.category.localeCompare(b.category, "ja");
  });

  return rows;
}
