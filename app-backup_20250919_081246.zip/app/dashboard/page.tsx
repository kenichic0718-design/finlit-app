"use client";

import React, { useEffect, useMemo, useState } from "react";
import { getSupabaseClient } from "@/lib/supabaseClient";
import { getCurrentProfileId } from "../_utils/getCurrentProfileId";
import { fetchBudgetVsActual, monthRangeFromYyyymm, BudgetActualRow } from "../_utils/budgetActual";

function toYyyymm(d: Date) {
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function fromYyyymm(yyyymm: string) {
  const y = yyyymm.slice(0, 4);
  const m = yyyymm.slice(4);
  return `${y}年${m}月`;
}
function shiftMonth(yyyymm: string, diff: number) {
  let y = Number(yyyymm.slice(0, 4));
  let m = Number(yyyymm.slice(4));
  m += diff;
  while (m <= 0) { m += 12; y -= 1; }
  while (m > 12) { m -= 12; y += 1; }
  return `${y}${String(m).padStart(2, "0")}`;
}

export default function DashboardPage() {
  const supabase = getSupabaseClient();
  const [profileId, setProfileId] = useState<string>("");
  const [yyyymm, setYyyymm] = useState<string>(() => toYyyymm(new Date()));
  const [rows, setRows] = useState<BudgetActualRow[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const periodLabel = useMemo(() => fromYyyymm(yyyymm), [yyyymm]);

  useEffect(() => {
    (async () => {
      const pid = await getCurrentProfileId(supabase);
      setProfileId(pid);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    (async () => {
      if (!profileId) return;
      setLoading(true);
      try {
        const data = await fetchBudgetVsActual(supabase, profileId, yyyymm);
        setRows(data);
      } finally {
        setLoading(false);
      }
    })();
  }, [profileId, yyyymm, supabase]);

  const totalBudget = rows.reduce((s, r) => s + r.budget, 0);
  const totalActual = rows.reduce((s, r) => s + r.actual, 0);
  const progress = totalBudget ? Math.round((totalActual / totalBudget) * 100) : 0;

  const { from, to } = monthRangeFromYyyymm(yyyymm);

  return (
    <div className="mx-auto max-w-4xl p-6 space-y-6">
      <h1 className="text-xl font-bold">ダッシュボード</h1>

      <div className="flex items-center gap-2">
        <button
          className="border px-3 py-1 rounded"
          onClick={() => setYyyymm(shiftMonth(yyyymm, -1))}
        >
          ←
        </button>
        <div className="px-3 py-1 border rounded">{periodLabel}</div>
        <button
          className="border px-3 py-1 rounded"
          onClick={() => setYyyymm(shiftMonth(yyyymm, 1))}
        >
          →
        </button>
      </div>

      <div className="opacity-80 text-sm">
        期間: {from} 〜 / 予算: {totalBudget.toLocaleString()}円・実績: {totalActual.toLocaleString()}円・進捗: {progress}%
      </div>

      {loading ? (
        <div className="opacity-70">読み込み中...</div>
      ) : (
        <div className="border rounded">
          <table className="w-full text-sm">
            <thead className="opacity-70">
              <tr>
                <th className="text-left p-2">カテゴリ</th>
                <th className="text-right p-2">予算</th>
                <th className="text-right p-2">実績</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.category} className="border-t">
                  <td className="p-2">{r.category}</td>
                  <td className="p-2 text-right">{r.budget.toLocaleString()}円</td>
                  <td className="p-2 text-right">{r.actual.toLocaleString()}円</td>
                </tr>
              ))}
              {rows.length === 0 && (
                <tr>
                  <td className="p-3 opacity-70" colSpan={3}>
                    データがありません。
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
