export default function Home() {
  return <p>ホーム（レイアウト確認用）</p>;
}

