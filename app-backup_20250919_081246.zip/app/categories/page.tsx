"use client";
import { getSupabaseClient } from "@/lib/supabaseClient";
import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabaseClient";

type Category = { id: string; name: string; kind: "expense" | "income"; color: string };

export default function CategoriesPage() {
  const supabase = getSupabaseClient();
  const [list, setList] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [kind, setKind] = useState<"expense"|"income">("expense");
  const [color, setColor] = useState("#60a5fa");
  const [saving, setSaving] = useState(false);

  async function fetchList() {
    const { data, error } = await supabase.from("categories").select("*").order("created_at",{ascending:true});
    if (!error && data) setList(data as Category[]);
  }
  useEffect(()=>{ fetchList(); },[]);

  async function addCategory() {
    if (!name.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("categories").insert({ name: name.trim(), kind, color });
    setSaving(false);
    if (error) return alert("追加に失敗しました");
    setName("");
    fetchList();
  }

  async function updateCategory(id: string, patch: Partial<Category>) {
    const { error } = await supabase.from("categories").update(patch).eq("id", id);
    if (error) return alert("更新に失敗しました");
    fetchList();
  }

  async function removeCategory(id: string) {
    if (!confirm("削除してよいですか？")) return;
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return alert("削除に失敗しました");
    fetchList();
  }

  return (
    <main className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex gap-3">
        <Link href="/dashboard" className="px-3 py-1 rounded bg-gray-700 hover:bg-gray-600 text-white">ダッシュボード</Link>
        <Link href="/log" className="px-3 py-1 rounded bg-gray-700 hover:bg-gray-600 text-white">記録</Link>
      </div>

      <h1 className="text-2xl font-bold">カテゴリ管理</h1>

      <section className="p-4 rounded border border-gray-700">
        <h2 className="font-semibold mb-2">新規追加</h2>
        <div className="flex flex-wrap items-center gap-3">
          <input className="px-3 py-2 rounded bg-gray-800 border border-gray-600"
                 placeholder="カテゴリ名（例：アルバイト）" value={name}
                 onChange={(e)=>setName(e.target.value)} />
          <select className="px-3 py-2 rounded bg-gray-800 border border-gray-600"
                  value={kind} onChange={(e)=>setKind(e.target.value as any)}>
            <option value="expense">支出</option>
            <option value="income">収入</option>
          </select>
          <input type="color" value={color} onChange={(e)=>setColor(e.target.value)} />
          <button onClick={addCategory}
                  disabled={saving}
                  className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50">
            追加
          </button>
        </div>
      </section>

      <section className="p-4 rounded border border-gray-700">
        <h2 className="font-semibold mb-3">一覧</h2>
        <div className="space-y-2">
          {list.map(c=>(
            <div key={c.id} className="flex items-center gap-3 p-3 rounded border border-gray-700">
              <span className="w-4 h-4 rounded" style={{background:c.color}} />
              <input className="px-2 py-1 rounded bg-gray-800 border border-gray-600"
                     value={c.name} onChange={(e)=>updateCategory(c.id,{name:e.target.value})}/>
              <select className="px-2 py-1 rounded bg-gray-800 border border-gray-600"
                      value={c.kind} onChange={(e)=>updateCategory(c.id,{kind:e.target.value as any})}>
                <option value="expense">支出</option>
                <option value="income">収入</option>
              </select>
              <input type="color" value={c.color} onChange={(e)=>updateCategory(c.id,{color:e.target.value})}/>
              <button onClick={()=>removeCategory(c.id)}
                      className="ml-auto px-3 py-1 rounded bg-red-600 hover:bg-red-500">削除</button>
            </div>
          ))}
          {!list.length && <div className="text-sm text-gray-400">まだカテゴリがありません。</div>}
        </div>
      </section>
    </main>
  );
}
